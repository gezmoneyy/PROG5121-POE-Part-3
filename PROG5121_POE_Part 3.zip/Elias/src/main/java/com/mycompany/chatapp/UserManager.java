/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

import java.util.ArrayList;
import java.util.Scanner;
 
/*
 * AccountManager stores all registered user data
 * and handles the full sign-up flow.
 * It validates every field before saving the user's details.
 */
class AccountManager {
 
    // Separate lists that store each registered user's details
    static ArrayList<String> registeredUsernames  = new ArrayList<>();
    static ArrayList<String> registeredPasswords  = new ArrayList<>();
    static ArrayList<String> registeredPhones     = new ArrayList<>();
    static ArrayList<String> registeredFirstNames = new ArrayList<>();
    static ArrayList<String> registeredLastNames  = new ArrayList<>();
 
    // ==================== VALIDATION METHODS ====================
 
    // A name is valid if it contains only letters and is not blank
    public static boolean isNameValid(String name) {
        if (name.isEmpty()) return false;
        for (char ch : name.toCharArray()) {
            if (!Character.isLetter(ch)) return false;
        }
        return true;
    }
 
    // Username must be 5 characters or fewer and must include an underscore
    public static boolean isUsernameValid(String username) {
        return username.length() <= 5 && username.contains("_");
    }
 
    // Password needs at least 8 characters, one uppercase, one digit, one special character
    public static boolean isPasswordValid(String password) {
        if (password.length() < 8) return false;
        boolean hasUpper   = password.matches(".*[A-Z].*");
        boolean hasDigit   = password.matches(".*\\d.*");
        boolean hasSpecial = password.matches(".*[^a-zA-Z0-9].*");
        return hasUpper && hasDigit && hasSpecial;
    }
 
    // Phone number must follow the South African format: +27 followed by exactly 9 digits
    public static boolean isPhoneValid(String phone) {
        return phone.matches("^\\+27\\d{9}$");
    }
 
    // Returns true if the username is already taken
    public static boolean isUsernameTaken(String username) {
        return registeredUsernames.contains(username);
    }
 
    // ==================== INPUT COLLECTION METHODS ====================
 
    // Keeps asking for a first name until the user enters letters only
    public static String promptFirstName(Scanner input) {
        String firstName;
        do {
            System.out.print("First name (letters only): ");
            firstName = input.nextLine().trim();
            if (!isNameValid(firstName)) {
                System.out.println("First name must contain letters only. Try again.\n");
            }
        } while (!isNameValid(firstName));
        return firstName;
    }
 
    // Keeps asking for a last name until the user enters letters only
    public static String promptLastName(Scanner input) {
        String lastName;
        do {
            System.out.print("Last name (letters only): ");
            lastName = input.nextLine().trim();
            if (!isNameValid(lastName)) {
                System.out.println("Last name must contain letters only. Try again.\n");
            }
        } while (!isNameValid(lastName));
        return lastName;
    }
 
    // Keeps asking for a username until it is valid and not already taken
    public static String promptUsername(Scanner input) {
        String username;
        do {
            System.out.print("Choose a username (max 5 characters, must include '_'): ");
            username = input.nextLine().trim();
 
            if (!isUsernameValid(username)) {
                System.out.println("Username must be 5 characters or fewer and contain an underscore.\n");
                username = ""; // Force the loop to continue
            } else if (isUsernameTaken(username)) {
                System.out.println("That username is already taken. Please choose another.\n");
                username = ""; // Force the loop to continue
            }
        } while (username.isEmpty());
        return username;
    }
 
    // Keeps asking for a password until it meets all the requirements
    public static String promptPassword(Scanner input) {
        String password;
        do {
            System.out.print("Create a password (8+ characters, 1 uppercase, 1 number, 1 special character): ");
            password = input.nextLine().trim();
            if (!isPasswordValid(password)) {
                System.out.println("Password does not meet the requirements. Please try again.\n");
            }
        } while (!isPasswordValid(password));
        return password;
    }
 
    // Keeps asking for a South African phone number until it is correctly formatted
    public static String promptPhone(Scanner input) {
        String phone;
        do {
            System.out.print("Phone number (format: +27XXXXXXXXX): ");
            phone = input.nextLine().trim();
            if (!isPhoneValid(phone)) {
                System.out.println("Phone must start with +27 followed by 9 digits. E.g. +27821234567\n");
            }
        } while (!isPhoneValid(phone));
        return phone;
    }
 
    // ==================== REGISTRATION METHOD ====================
 
    /*
     * Runs the full registration flow.
     * Collects and validates all details, then saves them.
     * Returns a message telling the user if registration was successful.
     */
    public static String registerNewUser(Scanner input) {
        System.out.println("\n===== CREATE YOUR SWIFTCHAT ACCOUNT =====\n");
 
        // Collect each piece of information one by one
        String firstName = promptFirstName(input);
        String lastName  = promptLastName(input);
        String username  = promptUsername(input);
        String password  = promptPassword(input);
        String phone     = promptPhone(input);
 
        // Save all details to the registered user lists
        registeredFirstNames.add(firstName);
        registeredLastNames.add(lastName);
        registeredUsernames.add(username);
        registeredPasswords.add(password);
        registeredPhones.add(phone);
 
        return "Registration successful! Welcome to SwiftChat, " + firstName + "!";
    }
}