/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
 
/*
 * MessageService manages all messaging in SwiftChat.
 * It creates messages, validates recipients,
 * builds message fingerprints, and stores sent messages.
 */
class MessageService {
 
    // Lists that hold the details of every sent message
    static ArrayList<String> allMessageIDs   = new ArrayList<>();
    static ArrayList<String> allFingerprints = new ArrayList<>();
    static ArrayList<String> allRecipients   = new ArrayList<>();
    static ArrayList<String> allMessageTexts = new ArrayList<>();
 
    // Part 3 — holds only messages the user chose to SEND
    static ArrayList<String> sentMessages = new ArrayList<>();
 
    // Part 3 — holds only messages the user chose to DISCARD
    static ArrayList<String> disregardedMessages = new ArrayList<>();
 
    // Part 3 — four parallel arrays for messages saved to the JSON file.
    // Each index represents one stored message — all four stay in sync.
    static ArrayList<String> storedMessageTexts = new ArrayList<>();
    static ArrayList<String> storedRecipients   = new ArrayList<>();
    static ArrayList<String> storedHashes       = new ArrayList<>(); // message hash array
    static ArrayList<String> storedIDs          = new ArrayList<>(); // message ID array
 
    // Part 3 — file used to persist stored messages between sessions
    private static final String JSON_FILE = "stored_messages.json";
 
    // Tracks how many messages have been sent this session
    static int sentCount = 0;
 
    // Instance variables for one message
    private String messageID;
    private String recipient;
    private String messageText;
    private String fingerprint;
 
    // Constructor — builds a new message with a recipient and text
    public MessageService(String recipient, String messageText) {
        this.recipient   = recipient;
        this.messageText = messageText;
        this.messageID   = createMessageID();
        // Fingerprint is built after the ID is ready
        this.fingerprint = buildFingerprint();
    }
 
    // ==================== ID AND FINGERPRINT METHODS ====================
 
    // Generates a random 10-digit message ID
    public String createMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }
 
    // Returns true if the message ID is 10 characters or fewer
    public boolean isMessageIDValid() {
        return messageID.length() <= 10;
    }
 
    /*
     * Builds a fingerprint in the format:
     * first 2 digits of ID : message number : first word + last word
     * Example: "47:2:HELLOTHERE"
     * Everything is converted to uppercase.
     */
    public String buildFingerprint() {
        // Grab the first two characters of the message ID
        String idPrefix = messageID.substring(0, 2);
 
        // Use the current sent count as the message number
        int msgNumber = sentCount;
 
        // Split the message into words and grab the first and last
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord  = words[words.length - 1];
 
        return (idPrefix + ":" + msgNumber + ":" + firstWord + lastWord).toUpperCase();
    }
 
    // Validates recipient — must be +27 followed by exactly 9 digits (12 chars total)
    public String validateRecipient() {
        if (recipient.matches("^\\+27\\d{9}$")) {
            return "Recipient number captured successfully.";
        }
        return "Number must start with +27 and be followed by 9 digits (e.g. +27821234567).";
    }
 
    // ==================== MESSAGE ACTION METHOD ====================
 
    /*
     * Asks the user what to do with the composed message.
     * Options: send it, discard it, or save it for later.
     */
    public String handleMessageDecision(Scanner input) {
        System.out.println("\nWhat would you like to do with this message?");
        System.out.println("1. Send Message");
        System.out.println("2. Discard Message");
        System.out.println("3. Save Message for later");
        System.out.print("Your choice (1-3): ");
 
        String choice = input.nextLine().trim();
 
        switch (choice) {
            case "1":
                // Save the message and update the sent count
                sentCount++;
                allMessageIDs.add(messageID);
                allFingerprints.add(fingerprint);
                allRecipients.add(recipient);
                allMessageTexts.add(messageText);
                // Part 3 — also track in the dedicated sent array
                sentMessages.add(messageText);
                return "Message sent successfully.";
 
            case "2":
                // Discard — record the text so it can be reported later
                disregardedMessages.add(messageText);
                return "Message discarded.";
 
            case "3":
                // Save without sending — add to all stored arrays then write to file
                allMessageIDs.add(messageID);
                allFingerprints.add(fingerprint);
                allRecipients.add(recipient);
                allMessageTexts.add(messageText);
                // Part 3 — keep the four stored arrays in sync
                storedMessageTexts.add(messageText);
                storedRecipients.add(recipient);
                storedHashes.add(fingerprint);
                storedIDs.add(messageID);
                saveToFile(); // persist to JSON immediately
                return "Message saved. You can send it later.";
 
            default:
                return "Invalid choice. Message was not sent.";
        }
    }
 
    // ==================== DISPLAY METHODS ====================
 
    // Prints the details of this specific message
    public void showMessageSummary() {
        System.out.println("\n--- Message Summary ---");
        System.out.println("Message ID   : " + messageID);
        System.out.println("Fingerprint  : " + fingerprint);
        System.out.println("Recipient    : " + recipient);
        System.out.println("Message      : " + messageText);
    }
 
    // Prints all sent messages or a notice if none have been sent
    public static String displayAllMessages() {
        if (allMessageIDs.isEmpty()) {
            return "No messages have been sent yet.";
        }
 
        StringBuilder output = new StringBuilder("\n===== ALL SENT MESSAGES =====\n");
        for (int i = 0; i < allMessageIDs.size(); i++) {
            output.append("\nMessage ID   : ").append(allMessageIDs.get(i));
            output.append("\nFingerprint  : ").append(allFingerprints.get(i));
            output.append("\nRecipient    : ").append(allRecipients.get(i));
            output.append("\nMessage      : ").append(allMessageTexts.get(i));
            output.append("\n-----------------------------");
        }
        return output.toString();
    }
 
    // Returns how many messages have been sent this session
    public static int getTotalSent() {
        return sentCount;
    }
 
    // ==================== INPUT COLLECTION METHODS ====================
 
    // Asks how many messages the user wants to send and validates it is a whole number
    public static int promptMessageCount(Scanner input) {
        int count = 0;
        boolean isValid = false;
 
        System.out.print("\nHow many messages would you like to send? ");
 
        do {
            String raw = input.nextLine().trim();
            boolean allDigits = !raw.isEmpty();
 
            // Check every character is a digit
            for (char ch : raw.toCharArray()) {
                if (!Character.isDigit(ch)) {
                    allDigits = false;
                    break;
                }
            }
 
            if (allDigits) {
                count   = Integer.parseInt(raw);
                isValid = true;
            } else {
                System.out.print("Please enter a valid whole number: ");
            }
        } while (!isValid);
 
        return count;
    }
 
    // Asks for a recipient number — must be +27 followed by 9 digits (12 chars total)
    public static String promptRecipient(Scanner input) {
        String number;
        do {
            System.out.print("Recipient number (format: +27XXXXXXXXX): ");
            number = input.nextLine().trim();
            if (!number.matches("^\\+27\\d{9}$")) {
                System.out.println("Number must start with +27 followed by 9 digits. E.g. +27821234567\n");
            }
        } while (!number.matches("^\\+27\\d{9}$"));
        return number;
    }
 
    // Asks for a message and repeats if it exceeds 250 characters
    public static String promptMessageText(Scanner input) {
        String text;
        do {
            System.out.print("Type your message (max 250 characters): ");
            text = input.nextLine();
 
            if (text.length() > 250) {
                int excess = text.length() - 250;
                System.out.println("Message is " + excess + " character(s) too long. Please shorten it.\n");
            }
        } while (text.length() > 250);
        return text;
    }
 
    // ==================== MAIN MESSAGING FLOW ====================
 
    /*
     * Runs a full messaging session.
     * Asks how many messages, then loops through each one —
     * collecting, displaying and acting on each message.
     */
    public static void runMessagingSession(Scanner input) {
        int total = promptMessageCount(input);
 
        for (int i = 0; i < total; i++) {
            System.out.println("\n===== MESSAGE " + (i + 1) + " OF " + total + " =====");
 
            // Collect the recipient number and message text
            String number = promptRecipient(input);
            String text   = promptMessageText(input);
 
            // Create the message object
            MessageService msg = new MessageService(number, text);
 
            // Show the message details before the user decides what to do
            msg.showMessageSummary();
 
            // Let the user send, discard or save the message
            String outcome = msg.handleMessageDecision(input);
            System.out.println(outcome);
        }
 
        // After all messages, show the full list and session total
        System.out.println(displayAllMessages());
        System.out.println("\nMessages sent this session: " + getTotalSent());
    }
 
    // ==================== MESSAGING SCREEN ====================
 
    /*
     * Opens the SwiftChat messaging screen after a successful login.
     * Stays open until the user chooses to quit.
     * Part 3 — added option 3 "Stored Messages"; Quit is now option 4.
     */
    public static void openMessagingScreen(Scanner input) {
        System.out.println("\n**************************************************************************");
        System.out.println("   SWIFTCHAT MESSAGING  ");
        System.out.println("**************************************************************************");
 
        // Part 3 — reload any messages saved in a previous session
        loadFromFile();
 
        String option;
 
        do {
            System.out.println("\n===== MESSAGING MENU =====");
            System.out.println("1. Send Messages");
            System.out.println("2. View sent messages");
            System.out.println("3. Stored Messages"); // Part 3 — new option
            System.out.println("4. Quit");
            System.out.print("\nEnter your choice (1-4): ");
            option = input.nextLine().trim();
            System.out.println();
 
            switch (option) {
                case "1":
                    // Start a new messaging session
                    runMessagingSession(input);
                    break;
 
                case "2":
                    // Display all messages sent this session
                    System.out.println(displayAllMessages());
                    break;
 
                case "3":
                    // Part 3 — open the stored messages sub-menu
                    openStoredMessagesMenu(input);
                    break;
 
                case "4":
                    System.out.println("Logged out. Returning to main menu.");
                    break;
 
                default:
                    System.out.println("Invalid choice. Please enter 1, 2, 3 or 4.");
            }
 
        } while (!option.equals("4"));
    }
 
    // ==================== PART 3 — STORED MESSAGES MENU ====================
 
    /*
     * Sub-menu for "Stored Messages".
     * Gives the user six actions they can perform on the stored arrays.
     */
    public static void openStoredMessagesMenu(Scanner input) {
        String option;
 
        do {
            System.out.println("===== STORED MESSAGES MENU =====");
            System.out.println("1. Display sender and recipient of all stored messages");
            System.out.println("2. Display the longest stored message");
            System.out.println("3. Search by Message ID");
            System.out.println("4. Search messages by recipient");
            System.out.println("5. Delete a message using its hash");
            System.out.println("6. Display stored messages report");
            System.out.println("7. Back");
            System.out.print("\nEnter your choice (1-7): ");
            option = input.nextLine().trim();
            System.out.println();
 
            switch (option) {
                case "1":
                    displayStoredSendersAndRecipients();
                    break;
                case "2":
                    displayLongestStoredMessage();
                    break;
                case "3":
                    searchByID(input);
                    break;
                case "4":
                    searchByRecipient(input);
                    break;
                case "5":
                    deleteByHash(input);
                    break;
                case "6":
                    displayStoredReport();
                    break;
                case "7":
                    System.out.println("Returning to Messaging Menu.");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter 1-7.");
            }
        } while (!option.equals("7"));
    }
 
    // Part 3a — shows sender ("You") and recipient for every stored message
    public static void displayStoredSendersAndRecipients() {
        if (storedMessageTexts.isEmpty()) {
            System.out.println("No stored messages found.\n");
            return;
        }
        System.out.println("===== STORED MESSAGE SENDERS & RECIPIENTS =====");
        for (int i = 0; i < storedMessageTexts.size(); i++) {
            System.out.println("Message " + (i + 1) + ":");
            System.out.println("  Sender    : You");
            System.out.println("  Recipient : " + storedRecipients.get(i));
        }
        System.out.println();
    }
 
    // Part 3b — finds and prints the longest stored message by comparing lengths
    public static void displayLongestStoredMessage() {
        if (storedMessageTexts.isEmpty()) {
            System.out.println("No stored messages found.\n");
            return;
        }
        // Start with the first message as the baseline
        String longest = storedMessageTexts.get(0);
        for (String msg : storedMessageTexts) {
            if (msg.length() > longest.length()) {
                longest = msg; // replace if this one is longer
            }
        }
        System.out.println("Longest stored message:");
        System.out.println("  \"" + longest + "\"\n");
    }
 
    // Part 3c — searches stored messages by ID and prints the match
    public static void searchByID(Scanner input) {
        System.out.print("Enter Message ID to search: ");
        String searchID = input.nextLine().trim();
 
        boolean found = false;
        for (int i = 0; i < storedIDs.size(); i++) {
            if (storedIDs.get(i).equals(searchID)) {
                System.out.println("Recipient : " + storedRecipients.get(i));
                System.out.println("Message   : " + storedMessageTexts.get(i));
                found = true;
                break; // IDs are unique — stop after first match
            }
        }
        if (!found) {
            System.out.println("No stored message found with that ID.");
        }
        System.out.println();
    }
 
    // Part 3d — finds every stored message sent to a given recipient number
    public static void searchByRecipient(Scanner input) {
        System.out.print("Enter recipient number (+27XXXXXXXXX): ");
        String searchNum = input.nextLine().trim();
 
        boolean found = false;
        System.out.println("Messages for " + searchNum + ":");
        for (int i = 0; i < storedRecipients.size(); i++) {
            if (storedRecipients.get(i).equals(searchNum)) {
                System.out.println("  \"" + storedMessageTexts.get(i) + "\"");
                found = true; // keep going — there may be more than one
            }
        }
        if (!found) {
            System.out.println("  No stored messages found for that number.");
        }
        System.out.println();
    }
 
    /*
     * Part 3e — deletes one stored message by matching its hash (fingerprint).
     * Removes the entry from all four stored arrays and re-saves the file.
     */
    public static void deleteByHash(Scanner input) {
        System.out.print("Enter message hash to delete: ");
        String searchHash = input.nextLine().trim().toUpperCase();
 
        boolean found = false;
        for (int i = 0; i < storedHashes.size(); i++) {
            if (storedHashes.get(i).equalsIgnoreCase(searchHash)) {
                String deletedText = storedMessageTexts.get(i);
                // Remove the same index from every stored array to keep them in sync
                storedIDs.remove(i);
                storedRecipients.remove(i);
                storedHashes.remove(i);
                storedMessageTexts.remove(i);
                saveToFile(); // update the file so delete persists
                System.out.println("Message: \"" + deletedText + "\" successfully deleted.\n");
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("No stored message found with that hash.\n");
        }
    }
 
    // Part 3f — full report showing hash, recipient, and text for every stored message
    public static void displayStoredReport() {
        if (storedMessageTexts.isEmpty()) {
            System.out.println("No stored messages to report.\n");
            return;
        }
        System.out.println("===== STORED MESSAGES REPORT =====");
        for (int i = 0; i < storedMessageTexts.size(); i++) {
            System.out.println("\nMessage Hash : " + storedHashes.get(i));
            System.out.println("Recipient    : " + storedRecipients.get(i));
            System.out.println("Message      : " + storedMessageTexts.get(i));
            System.out.println("----------------------------------");
        }
        System.out.println();
    }
 
    // ==================== PART 3 — FILE PERSISTENCE ====================
 
    /*
     * Saves all stored messages to a plain-text file in a simple format.
     * No external library needed — uses standard Java file I/O.
     * Format per message: four lines (id, recipient, hash, message) then a blank line.
     */
    public static void saveToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(JSON_FILE))) {
            for (int i = 0; i < storedMessageTexts.size(); i++) {
                writer.println("ID:" + storedIDs.get(i));
                writer.println("RECIPIENT:" + storedRecipients.get(i));
                writer.println("HASH:" + storedHashes.get(i));
                writer.println("MESSAGE:" + storedMessageTexts.get(i));
                writer.println(); // blank line separates entries
            }
        } catch (IOException e) {
            System.out.println("Warning: could not save stored messages.");
        }
    }
 
    /*
     * Reads the saved file back into the four stored arrays.
     * Called once when the messaging screen opens.
     * Clears existing data first to avoid loading duplicates.
     */
    public static void loadFromFile() {
        // Clear in-memory data before reloading
        storedMessageTexts.clear();
        storedRecipients.clear();
        storedHashes.clear();
        storedIDs.clear();
 
        try (BufferedReader reader = new BufferedReader(new FileReader(JSON_FILE))) {
            String line;
            String id = null, recipient = null, hash = null, message = null;
 
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("ID:")) {
                    id = line.substring(3);
                } else if (line.startsWith("RECIPIENT:")) {
                    recipient = line.substring(10);
                } else if (line.startsWith("HASH:")) {
                    hash = line.substring(5);
                } else if (line.startsWith("MESSAGE:")) {
                    message = line.substring(8);
                } else if (line.isEmpty() && id != null) {
                    // Blank line means we have a complete entry — add it
                    storedIDs.add(id);
                    storedRecipients.add(recipient);
                    storedHashes.add(hash);
                    storedMessageTexts.add(message);
                    id = null; recipient = null; hash = null; message = null;
                }
            }
            // Handle the last entry if the file doesn't end with a blank line
            if (id != null) {
                storedIDs.add(id);
                storedRecipients.add(recipient);
                storedHashes.add(hash);
                storedMessageTexts.add(message);
            }
        } catch (IOException e) {
            // File doesn't exist yet — nothing to load on first run, that's fine
        }
    }
}