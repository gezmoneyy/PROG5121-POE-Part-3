/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

import java.util.Scanner;
 
/*
 * LoginHandler checks the user's credentials and logs them in.
 * It keeps asking for a username and password until
 * the correct combination is entered.
 */
class LoginHandler {
 
    // Checks whether the entered username and password match a registered account
    public static boolean areCredentialsValid(String username, String password) {
        for (int i = 0; i < AccountManager.registeredUsernames.size(); i++) {
            boolean usernameMatch = AccountManager.registeredUsernames.get(i).equals(username);
            boolean passwordMatch = AccountManager.registeredPasswords.get(i).equals(password);
            if (usernameMatch && passwordMatch) return true;
        }
        return false;
    }
 
    // Returns a success or failure message depending on the login result
    public static String buildLoginMessage(boolean loginSuccessful) {
        if (loginSuccessful) {
            return "Login successful!";
        }
        return "Incorrect username or password. Please try again.";
    }
 
    // Looks up and returns the full name for a given username
    public static String lookUpFullName(String username) {
        for (int i = 0; i < AccountManager.registeredUsernames.size(); i++) {
            if (AccountManager.registeredUsernames.get(i).equals(username)) {
                String first = AccountManager.registeredFirstNames.get(i);
                String last  = AccountManager.registeredLastNames.get(i);
                return first + " " + last;
            }
        }
        return ""; // Username not found (shouldn't happen after a successful login)
    }
 
    // Prints a personalised welcome message using the user's full name
    public static void showWelcomeGreeting(String username) {
        String fullName = lookUpFullName(username);
        System.out.println("Welcome back, " + fullName + "!\n");
    }
 
    /*
     * Runs the login loop.
     * Keeps asking for credentials until the correct ones are entered.
     * Returns true so ChatApp knows login was successful.
     */
    public static boolean runLoginProcess(Scanner input) {
        System.out.println("\n===== LOG IN TO SWIFTCHAT =====\n");
 
        String username;
        String password;
        boolean loginSuccessful;
 
        do {
            // Collect credentials from the user
            System.out.print("Username: ");
            username = input.nextLine().trim();
 
            System.out.print("Password: ");
            password = input.nextLine().trim();
 
            // Check if the credentials match a registered account
            loginSuccessful = areCredentialsValid(username, password);
            System.out.println(buildLoginMessage(loginSuccessful));
 
            if (loginSuccessful) {
                // Greet the user by name on a successful login
                showWelcomeGreeting(username);
            } else {
                System.out.println("Please try again.\n");
            }
 
        } while (!loginSuccessful);
 
        return true;
    }
}